Beypro Bridge
macOS: open "Run Beypro Bridge.command"
Windows: double-click "Run Beypro Bridge.bat"
Linux: run "./run.sh"
Then visit http://127.0.0.1:7777/ping  (should show {"ok":true})
