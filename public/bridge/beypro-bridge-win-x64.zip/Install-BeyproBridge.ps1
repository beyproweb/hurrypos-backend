$ErrorActionPreference="Stop"
$Log = "$env:LOCALAPPDATA\BeyproBridge\install.log"
New-Item -ItemType Directory -Force -Path (Split-Path $Log) | Out-Null
Start-Transcript -Path $Log -Append | Out-Null
try {
  Write-Host "Installing Beypro Bridge (Windows)..."
  $zipDir = Split-Path -Parent $MyInvocation.MyCommand.Path
  $srcExe = Join-Path $zipDir "local-print-bridge-win-x64.exe"
  $destDir = Join-Path $env:LOCALAPPDATA "BeyproBridge"
  $destExe = Join-Path $destDir "local-print-bridge-win-x64.exe"
  $startup = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup\Beypro Bridge.lnk"

  New-Item -ItemType Directory -Force -Path $destDir | Out-Null
  Copy-Item $srcExe $destExe -Force

  $wsh = New-Object -ComObject WScript.Shell
  $sc = $wsh.CreateShortcut($startup)
  $sc.TargetPath = $destExe
  $sc.WorkingDirectory = $destDir
  $sc.Save()

  Start-Process -FilePath $destExe
  Write-Host "Ping:"
  try { (Invoke-WebRequest -UseBasicParsing http://127.0.0.1:7777/ping).Content | Write-Host } catch {}
  Write-Host "✅ Installed. Bridge will auto-start on login."
}
catch {
  Write-Host "❌ Install failed: $($_.Exception.Message)"
  throw
}
finally {
  Stop-Transcript | Out-Null
  Write-Host ""
  Write-Host "📄 Log saved at $Log"
  Write-Host "Press any key to exit..."
  $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
