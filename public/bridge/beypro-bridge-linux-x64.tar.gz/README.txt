Beypro Bridge — How to run

macOS:
1) Unzip.
2) In Terminal: chmod +x local-print-bridge
3) Run: ./local-print-bridge
4) In Beypro → Settings → Printer: Local Bridge URL = http://127.0.0.1:7777

Windows:
1) Unzip.
2) Double-click local-print-bridge.exe and keep it open.

Linux:
1) tar -xzf beypro-bridge-linux-x64.tar.gz
2) chmod +x local-print-bridge-linux-x64 && ./local-print-bridge-linux-x64
