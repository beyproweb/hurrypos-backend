#!/bin/sh
set -e
LOG="$HOME/.cache/beypro-bridge-install.log"
mkdir -p "$(dirname "$LOG")"
{
  echo "Installing Beypro Bridge (Linux)..."
  DEST="$HOME/BeyproBridge"
  mkdir -p "$DEST"
  cp -f "$(dirname "$0")/local-print-bridge-linux-x64" "$DEST/local-print-bridge-linux-x64"
  chmod +x "$DEST/local-print-bridge-linux-x64"

  mkdir -p "$HOME/.config/systemd/user"
  cat > "$HOME/.config/systemd/user/beypro-bridge.service" <<EOF
[Unit]
Description=Beypro Bridge
[Service]
ExecStart=%h/BeyproBridge/local-print-bridge-linux-x64
Restart=always
WorkingDirectory=%h/BeyproBridge
[Install]
WantedBy=default.target
EOF

  systemctl --user daemon-reload
  systemctl --user enable --now beypro-bridge.service || true

  echo "Ping:"
  curl -s http://127.0.0.1:7777/ping || true
  echo "✅ Installed. Bridge will auto-start on login."
} | tee -a "$LOG"

echo
echo "📄 Log saved at $LOG"
printf "Press Enter to exit..."
read _
